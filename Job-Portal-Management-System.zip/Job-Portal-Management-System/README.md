# Job Portal Management System
This is a Data Base Management System that helps in managing the data of a Job Portal.

## Technologies Used
1. HTML
2. CSS
3. PHP
4. MySQL


*Username*: root  
*Password*:

**If you like the project please, star the repository. And for any doubts create an issue, I will try to resolve it ASAP.**

